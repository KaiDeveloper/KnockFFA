<?php

declare(strict_types=1);

namespace NexiusPE\KnockbackFFA;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\Color;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as f;

class KnockbackFFA extends PluginBase implements Listener
{

	const NAME = f::DARK_GRAY . "[" . f::YELLOW . "Knockback" . f::GOLD . "FFA" . f::DARK_GRAY . "]";
	const PREFIX = f::DARK_GRAY . "[" . f::YELLOW . "Knockback" . f::GOLD . "FFA" . f::DARK_GRAY . "] | " . f::WHITE;
	public $hitArray = array();
	public $fjoin = false;

	public function onEnable(): void
	{
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info(self::PREFIX . "KnockbackFFA wurde geladen!");
		@mkdir("/Data");
		@mkdir("/Data/KnockbackFFA");
	}

	public function giveElo(Player $player) {
		$name = $player->getName();
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		$array = (array)$c->get("$name");
		mt_srand(ip2long($player->getAddress())+time());
		$elo = mt_rand(1, 25);
		$array["elo"] = (int)$array["elo"]+$elo;
		$c->set("$name", $array);
		$c->save();
		$player->sendPopup(f::GREEN."+ $elo Elo");
	}

	public function rmElo(Player $player) {
		$name = $player->getName();
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		$array = (array)$c->get("$name");
		mt_srand(ip2long($player->getAddress())+time());
		$elo = mt_rand(1, 25);
		$array["elo"] = (int)$array["elo"]-$elo;
		$c->set("$name", $array);
		$c->save();
		$player->sendPopup(f::RED."- $elo Elo");
	}

	public function giveKill(Player $player) {
		$name = $player->getName();
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		$array = (array)$c->get("$name");
		$array["kills"] = (int)$array["kills"]+1;
		$c->set("$name", $array);
		$c->save();
		$player->sendPopup(f::GREEN."+ 1 Kill");
	}
	public function giveKillstreak(Player $player) {
		$name = $player->getName();
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		$array = (array)$c->get("$name");
		$array["killstreak"] = (int)$array["killstreak"]+1;
		$c->set("$name", $array);
		$c->save();
		$player->sendPopup(f::GREEN."+ 1 Kill");
	}
	public function rstKillstreak(Player $player) {
		$name = $player->getName();
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		$array = (array)$c->get("$name");
		$array["killstreak"] = (int)0;
		$c->set("$name", $array);
		$c->save();
	}

	public function getEq(Player $player) {
		$ainv = $player->getArmorInventory();
		$inv = $player->getInventory();
		$inv->clearAll();
		$ainv->clearAll();
		$brust = Item::get(Item::LEATHER_CHESTPLATE);
		mt_srand(ip2long($player->getAddress())+time());
		$brust->setCustomColor(new Color(mt_rand(0, 255), mt_rand(0, 255), mt_rand(0, 255)));
		$ainv->setChestplate($brust);
		$stick = Item::get(Item::STICK, 0, 1);
		$stick->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), 1));
		$inv->setItem(0, $stick);
	}

	public function onJoin(PlayerJoinEvent $event) {
		if($this->fjoin == false) {
			$this->fjoin = true;
			$this->getScheduler()->scheduleRepeatingTask(new KnockbackFFATask($this, $this->getServer()->getDefaultLevel
			()), 12);
		}
		$player = $event->getPlayer();
		$event->setJoinMessage(self::PREFIX.$player->getName()." has joined the Server!");
		$this->hitArray[$player->getName()] = "???";
		$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
		if($c->get($player->getName()) == false) {
			$c->set($player->getName(), ["kills" => 0, "elo" => 1000, "killstreak" => 0]);
			$c->save();
		}
		$this->getEq($player);
	}

	public function onPvp(EntityDamageByEntityEvent $event) {
		$opfer = $event->getEntity();
		$killer = $event->getDamager();
		if($killer instanceof Player and $opfer instanceof Player) {
			$this->hitArray[$opfer->getName()] = $killer->getName();
			$herzen = $opfer->getHealth();
			$schaden = $event->getFinalDamage();
			if($herzen - $schaden <= 0) {
				$event->setCancelled(true);
				$this->giveElo($killer);
				$this->rmElo($opfer);
				$this->getServer()->broadcastMessage(f::YELLOW.$killer->getName().f::WHITE." has killed ".f::YELLOW
					.$opfer->getName().f::WHITE."!");
				$opfer->setHealth(20);
				$opfer->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn()->asPosition());
				$this->getEq($opfer);
				$this->getEq($killer);
			}
		}
	}

	public function onVoid(EntityDamageEvent $event) {
		$opfer = $event->getEntity();
		if($opfer instanceof Player) {
			if($event->getCause() == EntityDamageEvent::CAUSE_VOID) {
				$event->setCancelled(true);
				$opfer->setHealth(20);
				$opfer->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
				$killername = $this->hitArray[$opfer->getName()];
				$killer = $this->getServer()->getPlayer($killername);
				$this->rmElo($opfer);
				$this->getServer()->broadcastMessage(f::YELLOW."$killername".f::WHITE." has knocked down ".f::YELLOW
					.$opfer->getName());
				$this->rstKillstreak($opfer);
				$this->getEq($opfer);
				$this->giveKill($killer);
				$this->getEq($killer);
				$this->giveElo($killer);
				$this->giveKillstreak($killer);
			} elseif($event->getCause() == EntityDamageEvent::CAUSE_FALL) {
				$event->setCancelled(true);
			}
		}
	}

	public function onRespawn(PlayerRespawnEvent $event) {
		$this->getEq($event->getPlayer());
	}
}
