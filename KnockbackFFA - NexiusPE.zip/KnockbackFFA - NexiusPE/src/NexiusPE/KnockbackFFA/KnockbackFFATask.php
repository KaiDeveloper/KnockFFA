<?php

namespace NexiusPE\KnockbackFFA;

use pocketmine\level\Level;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as f;
use pocketmine\utils\Config;

class KnockbackFFATask extends Task {

	public $pl;
	public $level;

	public function __construct(KnockbackFFA $plugin, Level $level)
	{
		$this->pl = $plugin;
		$this->level = $level;
	}

	public function onRun(int $currentTick)
	{
		$players = $this->level->getPlayers();
		foreach($players as $player) {
			$name = $player->getName();
			$c = new Config("/Data/KnockbackFFA/players.json", Config::JSON);
			$info = $c->get("$name");
			$kills = $info["kills"];
			$elo = $info["elo"];
			$killstreak = $info["killstreak"];
			$blank = "                                 ";
			$player->addActionBarMessage(
				f::BOLD.f::YELLOW."$blank $blank ⚔ NEXIUSPE ⚔\n".
				f::BOLD.f::WHITE."$blank $blank Kills: ".f::GOLD."$kills\n".
				f::BOLD.f::WHITE."$blank $blank Elo: ".f::GOLD."$elo\n".
				f::BOLD.f::WHITE."$blank $blank Killstreak: ".f::GOLD."$killstreak\n".
				f::BOLD.f::YELLOW."$blank $blank ⚔ NEXIUSPE ⚔\n\n\n\n\n\n\n\n\n\n\n");
		}
	}

}